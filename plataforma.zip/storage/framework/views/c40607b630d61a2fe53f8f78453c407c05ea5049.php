<?php $__env->startSection('title', 'Reservas'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
    <p class="caption"><strong>Reservas desde <?php echo e(now()->format('d-m-Y')); ?></strong></p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="card-panel ">

            <?php $__currentLoopData = $reservasPaginadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha => $reservas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col s12">
                <h5>Reservas: <?php echo e($fecha); ?></h5>
                <div class="row">
                    <div class="col s12 m6 l4">
                        <div class="card-panel animate__animated animate__backInDown"
                            style="--animate-delay: 1s; --animate-duration: 2s; ">
                            <table class="highlight">
                                <thead>
                                    <tr>
                                        <th>Sauna</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $reserva->visitas->sortBy('horario_sauna'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($visita->horario_sauna): ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('backoffice.reserva.show', $reserva)); ?>">
                                                <strong style="color:#FF4081;"><?php echo e($visita->horario_sauna); ?> - <?php echo e($visita->hora_fin_sauna); ?></strong>
                                                <strong><?php echo e(addslashes($reserva->cliente->nombre_cliente)); ?> -</strong>
                                                <?php echo e($visita->ubicacion->nombre); ?> -
                                                <?php echo e($reserva->programa->nombre_programa); ?> -
                                                <?php echo e($reserva->cantidad_personas); ?> personas -
                                                <?php if(is_null($reserva->observacion)): ?>
                                                Sin Observaciones
                                                <?php else: ?>
                                                <strong style="color:#FF4081;"><?php echo e($reserva->observacion); ?></strong>
                                                <?php endif; ?>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="col s12 m6 l4">
                        <div class="card-panel animate__animated animate__backInDown"
                            style="--animate-delay: 2s; --animate-duration: 2s; ">
                            <table class="highlight">
                                <thead>
                                    <tr>
                                        <th>Tinaja</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $reserva->visitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($visita->horario_tinaja): ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('backoffice.reserva.show', $reserva)); ?>">
                                                <strong style="color:#FF4081;"><?php echo e($visita->horario_tinaja); ?> - <?php echo e($visita->hora_fin_tinaja); ?></strong>
                                                <strong><?php echo e(addslashes($reserva->cliente->nombre_cliente)); ?> -</strong>
                                                <?php echo e($visita->ubicacion->nombre); ?> -
                                                <?php echo e($reserva->programa->nombre_programa); ?> -
                                                <?php echo e($reserva->cantidad_personas); ?> personas -
                                                <?php if(is_null($reserva->observacion)): ?>
                                                Sin Observaciones
                                                <?php else: ?>
                                                <strong style="color:#FF4081;"><?php echo e($reserva->observacion); ?></strong>
                                                <?php endif; ?>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="col s12 m6 l4">
                        <div class="card-panel animate__animated animate__backInDown"
                            style="--animate-delay: 3s; --animate-duration: 2s; ">
                            <table class="highlight">
                                <thead>
                                    <tr>
                                        <th>Masaje</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $reserva->visitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($visita->horario_masaje): ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('backoffice.reserva.show', $reserva)); ?>">
                                                <strong style="color: #FF4081"><?php echo e($visita->horario_masaje); ?> - <?php echo e($visita->hora_fin_masaje); ?></strong>
                                                <strong><?php echo e($reserva->cliente->nombre_cliente); ?> -</strong>
                                                <?php echo e($visita->ubicacion->nombre); ?> -
                                                <?php echo e($reserva->programa->nombre_programa); ?> -
                                                <?php echo e($reserva->cantidad_personas); ?> personas -
                                                <?php if(is_null($reserva->observacion)): ?>
                                                Sin Observaciones
                                                <?php else: ?>
                                                <strong style="color:#FF4081;"><?php echo e($reserva->observacion); ?></strong>
                                                <?php endif; ?>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php elseif(is_null($visita->horario_masaje)): ?>

                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('backoffice.reserva.show', $reserva)); ?>">
                                                <strong><?php echo e($reserva->cliente->nombre_cliente); ?> -</strong> No registra
                                                masaje
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Paginación -->
            <div class="center-align">
                <?php echo e($reservasPaginadas->links('vendor.pagination.materialize')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/reserva/index.blade.php ENDPATH**/ ?>