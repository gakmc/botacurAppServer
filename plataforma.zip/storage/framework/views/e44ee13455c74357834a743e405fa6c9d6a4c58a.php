<?php $__env->startSection('title','Nuestros Clientes'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.cliente.index')); ?>">Nuestros Clientes</a></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dropdown_settings'); ?>
<li><a href="<?php echo e(route ('backoffice.cliente.create')); ?>" class="grey-text text-darken-2">Crear Cliente</a></li> 
<!-- <li><a href="" class="grey-text text-darken-2">Crear Usuario</a></li> -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="section">
              <p class="caption"><strong>Nuestros Clientes</strong></p>
              <div class="divider"></div>
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 ">
                    <div class="card-panel">
                     
                      <div class="row">


                      <table>
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Correo</th>
                                    <th>Whatsapp</th>
                                    <th>Instagram</th>
                                    <th colspan="2">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><a href="<?php echo e(route('backoffice.cliente.show' ,$cliente )); ?>"><?php echo e($cliente->nombre_cliente); ?></a></td>
                                  <td><a href="mailto:<?php echo e($cliente->correo); ?>"><?php echo e($cliente->correo); ?></a></td>

                                  <td><?php if(is_null($cliente->whatsapp_cliente)): ?>
                                    No Registra
                                    <?php else: ?>
                                    <a href="https://api.whatsapp.com/send?phone=<?php echo e($cliente->whatsapp_cliente); ?>" target="_blank">+<?php echo e($cliente->whatsapp_cliente); ?></a>
                                  <?php endif; ?></td>


                                  <td><?php if(is_null($cliente->instagram_cliente)): ?>
                                    No Registra
                                    <?php else: ?>
                                    <a href="https://www.instagram.com/<?php echo e($cliente->instagram_cliente); ?>" target="_blank"><?php echo e($cliente->instagram_cliente); ?></a>
                                  <?php endif; ?></td>
                                  
                                  <td><a href="<?php echo e(route('backoffice.cliente.edit', $cliente )); ?>"><i class="material-icons">mode_edit</i> Editar</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/cliente/index.blade.php ENDPATH**/ ?>