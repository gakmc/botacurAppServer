<div class="collection">

    
    <a href="" class="collection-item active <?php if(is_null($reserva->venta)): ?>
        ''
    <?php else: ?>
        <?php if($reserva->venta->total_pagar === 0): ?>
            green
        <?php else: ?>
            ' '
        <?php endif; ?>
    <?php endif; ?>
    ">

        <h5 >Venta: <?php if(is_null($reserva->venta)): ?>
            
            <?php else: ?>
            <?php if($reserva->venta->total_pagar === 0): ?>
            Pagado
            <?php endif; ?>
            <?php endif; ?> </h5>
        </a>


    <?php if(is_null($reserva->venta)): ?>
    <a class="collection-item center">Esta reserva no posee venta. </a>
    
    <?php else: ?>
    
    <a class="collection-item center-align valign-wrapper left">
        Abono: <?php echo e($reserva->venta->abono_programa); ?>

    </a>
    <a class="collection-item center-align valign-wrapper left">
        Diferencia: <?php if(is_null($reserva->venta->diferencia_programa)): ?>
        Debe Realizar pago
        <?php else: ?>
        <?php echo e($reserva->venta->diferencia_programa); ?>

        <?php endif; ?>
    </a>
    <a href="#modal-venta<?php echo e($reserva->venta->id); ?>" class="modal-trigger collection-item center-align valign-wrapper left"
        data-id="<?php echo e($reserva->venta->id); ?>" 
        data-abono="<?php echo e($reserva->venta->abono_programa); ?>"
        data-abonoimg="<?php echo e($reserva->venta->imagen_abono ? route('backoffice.reserva.abono.imagen', $reserva->id) : '/images/gallary/no-image.png'); ?>" data-diferencia="<?php echo e($reserva->venta->diferencia_programa); ?>"
        data-diferenciaimg="<?php echo e($reserva->venta->imagen_diferencia ? route('backoffice.reserva.diferencia.imagen', $reserva->id) : '/images/gallary/no-image.png'); ?>" data-descuento="<?php echo e($reserva->venta->descuento); ?>"
        data-totalpagar="<?php echo e($reserva->venta->total_pagar); ?>" data-tipoabono="<?php echo e($reserva->venta->tipoTransaccionAbono->nombre ?? 'No registra'); ?>"
        data-tipodiferencia="<?php echo e($reserva->venta->tipoTransaccionDiferencia->nombre ?? 'No registra'); ?>"

        >
        <i class='material-icons tooltipped' data-position="bottom" data-tooltip="Ver Venta">remove_red_eye</i>
    </a>
    <a href="<?php echo e(route('backoffice.reserva.venta.edit', ['reserva'=>$reserva, 'ventum'=>$reserva->venta])); ?>" class="collection-item center-align valign-wrapper left">
        <i class='material-icons tooltipped' data-position="bottom" data-tooltip="Cerrar Venta">attach_money</i>
    </a>
    
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/reserva/includes/venta.blade.php ENDPATH**/ ?>