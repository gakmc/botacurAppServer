<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumbs'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('dropdown_settings'); ?>

<li><a href="<?php echo e(route ('backoffice.sectores.create')); ?>" class="grey-text text-darken-2">Crear Sector</a></li>
<li><a href="<?php echo e(route ('backoffice.ubicaciones.create')); ?>" class="grey-text text-darken-2">Crear Ubicacion</a></li>
<li><a href="<?php echo e(route ('backoffice.unidades_medidas.create')); ?>" class="grey-text text-darken-2">Crear Unidad de
        Medida</a></li>
<li><a href="<?php echo e(route ('backoffice.tipo_documentos.create')); ?>" class="grey-text text-darken-2">Crear Tipo de
        Documento</a></li>
<li><a href="<?php echo e(route ('backoffice.tipo_productos.create')); ?>" class="grey-text text-darken-2">Crear Tipo de
        Producto</a></li>
<li><a href="<?php echo e(route ('backoffice.tipo_transacciones.create')); ?>" class="grey-text text-darken-2">Crear Tipo de
        Transacción</a></li>
<li><a href="<?php echo e(route ('backoffice.categoria_compras.create')); ?>" class="grey-text text-darken-2">Crear Categoria
        Compra</a></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="section">
    <p class="caption"><strong>Complementos</strong></p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="row">

            
            <div class="col s12 m6">
                <div class="card-panel">
                    <div class="row">

                        
                        <div class="card-panel gradient-45deg-light-blue-cyan white-text center">
                            <h4>Sectores</h4>
                        </div>
                        <?php if($sectores->isNotEmpty()): ?>
                        <table class="centered responsive-table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th colspan="2">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sectores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>

                                        <?php echo e($sector->nombre); ?>


                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('backoffice.sector.edit', $sector->id)); ?>">
                                            <i class="material-icons">mode_edit</i> Editar
                                        </a>


                                    </td>

                                    <td>

                                        <a href="#" style="color: red"
                                            onclick="enviar_formulario('<?php echo e(route('backoffice.complemento.destroy', $sector->id)); ?>', 'sectores')">
                                            <i class="material-icons">delete</i> Eliminar
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <h5>No existen registros</h5>
                        <?php endif; ?>




                    </div>
                </div>
            </div>

            
            <div class="col s12 m6">
                <div class="card-panel">
                    <div class="row">

                        
                        <div class="card-panel gradient-45deg-light-blue-cyan white-text center">
                            <h4>Ubicaciones</h4>
                        </div>
                        <?php if($ubicaciones->isNotEmpty()): ?>
                        <table class="centered responsive-table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th colspan="2">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>

                                        <?php echo e($ubicacion->nombre); ?>


                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('backoffice.ubicacion.edit', $ubicacion->id)); ?>">
                                            <i class="material-icons">mode_edit</i> Editar
                                        </a>
                                    </td>
                                    <td>

                                        <a href="#" style="color: red"
                                            onclick="enviar_formulario('<?php echo e(route('backoffice.complemento.destroy', $ubicacion->id)); ?>', 'ubicaciones')">
                                            <i class="material-icons">delete</i> Eliminar
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <h5 class="center">No existen registros</h5>
                        <?php endif; ?>




                    </div>
                </div>
            </div>

        </div>
        <div class="row">

            
            <div class="col s12 m6">
                <div class="card-panel">
                    <div class="row">

                        
                        <div class="card-panel gradient-45deg-light-blue-cyan white-text center">
                            <h4>Tipos de Documentos</h4>
                        </div>
                        <?php if($documentos->isNotEmpty()): ?>
                        <table class="centered responsive-table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Descripcion</th>
                                    <th colspan="2">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>

                                        <?php echo e($documento->nombre); ?>


                                    </td>
                                    <td>
                                        <?php if(is_null($documento->descripcion)): ?>
                                        No Registra
                                        <?php else: ?>
                                        <?php echo e($documento->descripcion); ?>

                                        <?php endif; ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('backoffice.tipo_documento.edit', $documento->id)); ?>">
                                            <i class="material-icons">mode_edit</i> Editar
                                        </a>
                                    </td>

                                    <td>
                                        <a href="#" style="color: red"
                                            onclick="enviar_formulario('<?php echo e(route('backoffice.complemento.destroy', $documento->id)); ?>', 'tipos_documentos')">
                                            <i class="material-icons">delete</i> Eliminar
                                        </a>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <h5 class="center">No existen registros</h5>
                        <?php endif; ?>




                    </div>
                </div>
            </div>


            
            <div class="col s12 m6">
                <div class="card-panel">
                    <div class="row">

                        
                        <div class="card-panel gradient-45deg-light-blue-cyan white-text center">
                            <h4>Tipos de Transacciones</h4>
                        </div>
                        <?php if($transacciones->isNotEmpty()): ?>
                        <table class="centered responsive-table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th colspan="2">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transacciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>

                                        <?php echo e($transaccion->nombre); ?>


                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('backoffice.tipo_transaccion.edit', $transaccion->id)); ?>">
                                            <i class="material-icons">mode_edit</i> Editar
                                        </a>
                                    </td>
                                    <td>
                                        <a href="#" style="color: red"
                                            onclick="enviar_formulario('<?php echo e(route('backoffice.complemento.destroy', $transaccion->id)); ?>', 'tipos_transacciones')">
                                            <i class="material-icons">delete</i> Eliminar
                                        </a>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <h5 class="center">No existen registros</h5>
                        <?php endif; ?>




                    </div>
                </div>
            </div>


        </div>

        <div class="row">


            
            <div class="col s12 m6">
                <div class="card-panel">
                    <div class="row">

                        
                        <div class="card-panel gradient-45deg-light-blue-cyan white-text center">
                            <h4>Categoria Compras</h4>
                        </div>
                        <?php if($categorias->isNotEmpty()): ?>
                        <table class="centered responsive-table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th colspan="2">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>

                                        <?php echo e($categoria->nombre); ?>


                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('backoffice.categoria_compras.edit', $categoria->id)); ?>">
                                            <i class="material-icons">mode_edit</i> Editar
                                        </a>
                                    </td>

                                    <td>

                                        <a href="#" style="color: red"
                                            onclick="enviar_formulario('<?php echo e(route('backoffice.complemento.destroy', $categoria->id)); ?>', 'categoria_compras')">
                                            <i class="material-icons">delete</i> Eliminar
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <h5 class="center">No existen registros</h5>
                        <?php endif; ?>




                    </div>
                </div>
            </div>

            
            <div class="col s12 m6">
                <div class="card-panel">
                    <div class="row">

                        
                        <div class="card-panel gradient-45deg-light-blue-cyan white-text center">
                            <h4>Tipos de Productos</h4>
                        </div>
                        <?php if($tipoProductos->isNotEmpty()): ?>
                        <table class="centered responsive-table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Sector</th>

                                    <th colspan="2">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tipoProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoProducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>

                                        <?php echo e($tipoProducto->nombre); ?>


                                    </td>
                                    <td>

                                        <?php echo e($tipoProducto->sector->nombre); ?>.

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('backoffice.tipo_producto.edit', $tipoProducto->id)); ?>">
                                            <i class="material-icons">mode_edit</i> Editar
                                        </a>
                                    </td>
                                    <td>
                                        <a href="#" style="color: red"
                                            onclick="enviar_formulario('<?php echo e(route('backoffice.complemento.destroy', $tipoProducto->id)); ?>', 'productos')">
                                            <i class="material-icons">delete</i> Eliminar
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <h5 class="center">No existen registros</h5>
                        <?php endif; ?>




                    </div>
                </div>
            </div>


        </div>


        <div class="row">
                        
                        <div class="col s12 m6">
                            <div class="card-panel">
                                <div class="row">
            
                                    
                                    <div class="card-panel gradient-45deg-light-blue-cyan white-text center">
                                        <h4>Unidades de Medida</h4>
                                    </div>
                                    <?php if($unidades->isNotEmpty()): ?>
                                    <table class="centered responsive-table">
                                        <thead>
                                            <tr>
                                                <th>Nombre</th>
                                                <th>Abreviatura</th>
                                                <th>Tipo</th>
                                                <th>Descripcion</th>
                                                <th colspan="2">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
            
                                                    <?php echo e($unidad->nombre); ?>

            
                                                </td>
                                                <td>
            
                                                    <?php echo e($unidad->abreviatura); ?>.
            
                                                </td>
                                                <td>
            
                                                    <?php echo e(ucwords($unidad->tipo)); ?>

            
                                                </td>
                                                <td>
                                                    <?php if(is_null($unidad->descripcion)): ?>
                                                    No Registra
                                                    <?php else: ?>
                                                    <?php echo e($unidad->descripcion); ?>

                                                    <?php endif; ?>
            
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('backoffice.unidad_medida.edit', $unidad->id)); ?>">
                                                        <i class="material-icons">mode_edit</i> Editar
                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="#" style="color: red"
                                                        onclick="enviar_formulario('<?php echo e(route('backoffice.complemento.destroy', $unidad->id)); ?>', 'unidades_medidas')">
                                                        <i class="material-icons">delete</i> Eliminar
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php else: ?>
                                    <h5 class="center">No existen registros</h5>
                                    <?php endif; ?>
            
            
            
            
                                </div>
                            </div>
                        </div>
        </div>

    </div>
</div>
</div>
<form id="delete_form" method="post" action="">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('DELETE')); ?>

    <input type="hidden" name="table" id="table_name">
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<script>
    function enviar_formulario(actionUrl, table) {
    const form = document.getElementById('delete_form');
    form.action = actionUrl;
    document.getElementById('table_name').value = table; // Asegúrate de que este valor sea correcto

    Swal.fire({
        title: "¿Deseas eliminar este registro?",
        text: "Esta acción no se puede deshacer",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Sí, continuar",
        cancelButtonText: "No, cancelar",
        reverseButtons: true 
    }).then((result) => {
        if (result.isConfirmed) {
            form.submit(); 
        } else if (result.dismiss === Swal.DismissReason.cancel) {
            Swal.fire('Operación Cancelada', 'Registro no eliminado', 'error');
        }
    });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/complemento/index.blade.php ENDPATH**/ ?>