<?php $__env->startSection('title', 'Menus'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
    <p class="caption"><strong>Menus desde <?php echo e(now()->format('d-m-Y')); ?></strong></p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="card-panel ">


            <?php $__currentLoopData = $menusPaginados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha => $reservas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card-panel">
                <div class="card-content gradient-45deg-light-blue-cyan">
                    <h5 class="card-title center white-text"><i class='material-icons white-text'>restaurant_menu</i> Menús para <?php echo e($reserva->cliente->nombre_cliente); ?> / <?php echo e($fecha); ?></h5>
                </div>

                <div class="card-content  grey lighten-4">
                <table class="responsive-table">
                    <thead class="">
                      <tr>
                        <th>Menú</th>
                        <th>Entrada</th>
                        <th>Fondo</th>
                        <th>Acompañamiento</th>
                        <th>Observaciones</th>
                      </tr>
                    </thead>
                    <tbody>
                <?php $__currentLoopData = $reserva->visitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $visita->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>


                            <td>
                              <strong>Menú <?php echo e($index + 1); ?>:</strong>
                            </td>
                            <td>
                              <?php echo e($menu->productoEntrada->nombre); ?>

                            </td>
                            <td>
          
                              <?php echo e($menu->productoFondo->nombre); ?>

                            </td>
                            <td>
          
                              <?php echo e($menu->productoAcompanamiento->nombre); ?>

                            </td>
                            
                              <?php if($menu->observacion == null): ?>
                                <td> No Registra</td>
                              <?php endif; ?>
                              <td style="color: red"><?php echo e($menu->observacion); ?></td>
          
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
        <div class="center">
            <?php echo e($menusPaginados->links('vendor.pagination.materialize')); ?>

        </div>
        


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/cocina/index.blade.php ENDPATH**/ ?>