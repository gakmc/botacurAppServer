<?php $__env->startSection('title', 'Asignar Roles'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.user.index')); ?>">Usuarios del Sistema</a></li>
<li><a href="<?php echo e(route('backoffice.user.show', $user)); ?>"><?php echo e($user->name); ?></a></li>
<li>Asignar Rol</li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="section">
    <p class="caption">Selecciona los roles que deseas asignar</p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="row">
            <div class="col s12 m8">
                <div class="card-panel">
                    <h4 class="header2">Asignar Roles</h4>
                    <div class="row">
                        <form class="col s12" method="post" action="<?php echo e(route('backoffice.user.role_assignment', $user)); ?>">
                            <?php echo e(csrf_field()); ?>


                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p>
                                <input type="checkbox" id="<?php echo e($role->id); ?>" name="roles[]" value="<?php echo e($role->id); ?>"  <?php if($user->has_role($role->id)): ?> checked="" <?php endif; ?> />
                                    <label for="<?php echo e($role->id); ?>">
                                        <span><?php echo e($role->name); ?></span>
                                    </label>
                                </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                   
                                
                                <div class="row">
                                    <div class="input-field col s12">
                                        <button class="btn waves-effect waves-light right" type="submit">Guardar
                                            <i class="material-icons right">send</i>
                                        </button>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col s12 m4">
                    <?php echo $__env->make('themes.backoffice.pages.user.includes.user_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/user/assign_role.blade.php ENDPATH**/ ?>