<?php $__env->startSection('title','Roles del Sistema'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.role.index')); ?>">Roles del Sistema</a></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dropdown_settings'); ?>
<li><a href="<?php echo e(route ('backoffice.role.create')); ?>" class="grey-text text-darken-2">Crear Rol</a></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="section">
              <p class="caption"><strong>Roles del Sistema</strong></p>
              <div class="divider"></div>
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 ">
                    <div class="card-panel">
                     
                      <div class="row">


                      <table>
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Slug</th>
                                    <th>Descripción</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route ('backoffice.role.show',$role)); ?>"><?php echo e($role->name); ?></a></td>
                                    <td><?php echo e($role->slug); ?></td>
                                    <td><?php echo e($role->description); ?></td>
                                    <td><a href="<?php echo e(route ('backoffice.role.edit',$role)); ?>">Editar</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                    </table>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/role/index.blade.php ENDPATH**/ ?>