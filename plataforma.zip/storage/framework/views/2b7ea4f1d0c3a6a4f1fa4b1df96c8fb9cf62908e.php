<?php $__env->startSection('title','Planificar Visita'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.reserva.show', $reserva)); ?>">Reagendamiento para reserva del cliente</a></li>
<li>Planificar Visita</li>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="section">
    <p class="caption">Introduce los datos para planificar una Visita</p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="row">
            <div class="col s12 m8 offset-m2 ">
                <div class="card-panel">
                    <h4 class="header">Planificar visita para <strong><?php echo e($reserva->cliente->nombre_cliente); ?></strong> -
                        Fecha:<strong><?php echo e($reserva->fecha_visita); ?></strong></h4>
                    <div class="row">
                        <form class="col s12" method="post"
                            action="<?php echo e(route('backoffice.reserva.visitas.store', $reserva)); ?>">


                            <?php echo e(csrf_field()); ?>




                            <div class="row">
                                <div class="input-field col s12 m6 l4" hidden>
                                    <input id="id_reserva" type="hidden" class="form-control" name="id_reserva"
                                        value="<?php echo e($reserva->id); ?>" required>
                                </div>



                                <div class="input-field col s12 m6 l4">
                                    <select name="horario_sauna" id="horario_sauna">
                                        <option value="" selected disabled="">-- Seleccione --</option>
                                        <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($horario); ?>" <?php echo e(old('horario_sauna')==$horario ? 'selected'
                                            : ''); ?>>
                                            <?php echo e($horario); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['horario_sauna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong style="color:red"><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <label for="horario_sauna">Horario SPA</label>
                                </div>



                                

                                

                                <div class="input-field col s12 m6 l4" <?php if(!in_array('Masaje', $servicios) && !$masajesExtra): ?> style="display: none;"
                                    <?php endif; ?>>

                                    <select id="horario_masaje" name="horario_masaje" <?php if(!in_array('Masaje',
                                        $servicios) && !$masajesExtra): ?> disabled hidden <?php endif; ?>>

                                        <option value="" selected disabled="">-- Seleccione --</option>
                                        <?php $__currentLoopData = $horasMasaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($horario); ?>" <?php echo e(old('horario_sauna')==$horario ? 'selected'
                                            : ''); ?>>
                                            <?php echo e($horario); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                    <label for="horario_masaje">Horario Masaje</label>
                                    <?php $__errorArgs = ['horario_masaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong style="color:red"><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                                <div class="input-field col s12 m6 l4" <?php if(!in_array('Masaje', $servicios) && !$masajesExtra): ?> style="display: none;"
                                <?php endif; ?>>

                                <select id="tipo_masaje" name="tipo_masaje" <?php if(!in_array('Masaje',
                                    $servicios) && !$masajesExtra): ?> disabled hidden <?php endif; ?>>

                                    <option value="" disabled selected >-- Seleccione --</option>
                                    <option value="Relajante" <?php echo e(old('tipo_masaje') == 'Relajante' ? 'selected'
                                        : ''); ?>>
                                        Relajante
                                    </option>
                                    <option value="Descontracturante" <?php echo e(old('tipo_masaje') == 'Descontracturante' ? 'selected'
                                        : ''); ?>>
                                        Descontracturante
                                    </option>
                                    


                                </select>
                                <label for="tipo_masaje">Tipo Masaje</label>
                                <?php $__errorArgs = ['tipo_masaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong style="color:red"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>



                                <div class="input-field col s12 m6 l4">

                                    <label for="alergias">Alérgias</label>
                                    <input id="alergias" type="text" name="alergias" class=""
                                        value="<?php echo e(old('alergias')); ?>">
                                    <?php $__errorArgs = ['alergias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong style="color:red"><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="input-field col s12 m6 l4">

                                    <label for="observacion">Observaciones</label>
                                    <input id="observacion" type="text" name="observacion" class=""
                                        value="<?php echo e(old('observacion')); ?>">
                                    <?php $__errorArgs = ['observacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong style="color:red"><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>


                                <div class="input-field col s12 m6 l4">
                                    <select name="id_ubicacion" id="id_ubicacion">
                                        <option value="" selected disabled="">-- Seleccione --</option>
                                        <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ubicacion->id); ?>" <?php echo e(old('id_ubicacion')==$ubicacion->nombre ?
                                            'selected' : ''); ?>><?php echo e($ubicacion->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['id_ubicacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong style="color:red"><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <label for="id_ubicacion">Ubicación</label>
                                </div>

                                <div class="input-field col s12 m6 l4" <?php if(!in_array('Masaje', $servicios) && !$masajesExtra): ?> style="display: none;"
                                <?php endif; ?>>
                                    <select name="id_lugar_masaje" id="id_lugar_masaje" <?php if(!in_array('Masaje',
                                    $servicios) && !$masajesExtra): ?> disabled hidden <?php endif; ?>>
                                        <option value="" selected disabled="">-- Seleccione --</option>
                                        <?php $__currentLoopData = $lugares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lugar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($lugar->id); ?>" <?php echo e(old('id_lugar_masaje')==$lugar->nombre ?
                                            'selected' : ''); ?>><?php echo e($lugar->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['id_lugar_masaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong style="color:red"><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <label for="id_lugar_masaje">Lugar Masaje</label>
                                </div>




                                <div class="col s12 m6 l4">
                                    <label for="trago_cortesia">Trago cortesia</label>
                                    <p>
                                        <label>
                                            <input name="trago_cortesia" id="trago_cortesia" type="radio"
                                                class="with-gap" value="Si" />
                                            <span>Si</span>
                                        </label>

                                        <label>
                                            <input name="trago_cortesia" id="trago_cortesia" type="radio"
                                                class="with-gap" value="No" checked />
                                            <span>No</span>
                                        </label>
                                    </p>

                                    <?php $__errorArgs = ['trago_cortesia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong style="color:red"><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>



                            </div>

                            <div class="row"><br></div>

                            <div class="row">
                                <h6><strong> Menús por asistente</strong></h6>
                                
                                <?php for($i = 1; $i <= $reserva->cantidad_personas; $i++): ?>

                                    <div class="input-field col s12 m6 l3">
                                        <select name="menus[<?php echo e($i); ?>][id_producto_entrada]"
                                            id="id_producto_entrada_<?php echo e($i); ?>">
                                            <option value="" disabled selected> -- Seleccione --</option>
                                            <?php $__currentLoopData = $entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($entrada->id); ?>"><?php echo e($entrada->nombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_producto_entrada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong style="color:red"><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <label for="id_producto_entrada_<?php echo e($i); ?>">Entrada</label>
                                    </div>



                                    <div class="input-field col s12 m6 l3">
                                        <select name="menus[<?php echo e($i); ?>][id_producto_fondo]" id="id_producto_fondo_<?php echo e($i); ?>">
                                            <option value="" disabled selected> -- Seleccione --</option>
                                            <?php $__currentLoopData = $fondos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fondo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($fondo->id); ?>"><?php echo e($fondo->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_producto_fondo_<?php echo e($i); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong style="color:red"><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <label for="id_producto_fondo_<?php echo e($i); ?>">Fondo</label>
                                    </div>


                                    <div class="input-field col s12 m6 l3">
                                        <select name="menus[<?php echo e($i); ?>][id_producto_acompanamiento]" id="id_producto_acompanamiento_<?php echo e($i); ?>">
                                            <option value="" disabled selected> -- Seleccione --</option>
                                            <?php $__currentLoopData = $acompañamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acompañamiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($acompañamiento->id); ?>"><?php echo e($acompañamiento->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_producto_acompanamiento_<?php echo e($i); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong style="color:red"><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <label for="id_producto_acompanamiento_<?php echo e($i); ?>">Acompañamiento</label>
                                    </div>


                                    <div class="input-field col s12 m6 l3">
                                        <input type="text" name="menus[<?php echo e($i); ?>][observacion]"
                                            id="observacion_<?php echo e($i); ?>" />
                                        <label for="observacion_<?php echo e($i); ?>">Observaciones</label>
                                        <?php $__errorArgs = ['id_producto_entrada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong style="color:red"><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <?php endfor; ?>
                            </div>






                            <div class="row">
                                <div class="input-field col s12">
                                    <button class="btn waves-effect waves-light right" type="submit">Guardar
                                        <i class="material-icons right">send</i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/visita/create.blade.php ENDPATH**/ ?>