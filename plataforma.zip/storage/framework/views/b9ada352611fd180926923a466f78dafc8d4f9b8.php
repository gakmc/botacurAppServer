<?php $__env->startSection('title', $user->name); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.user.index')); ?>">Usuarios del Sistema</a></li>
<li><?php echo e($user->name); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dropdown_settings'); ?>
<li><a href="<?php echo e(route('backoffice.user.edit',$user)); ?>" class="grey-text text-darken-2">Editar Usuario</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
    <p class="caption"><strong>Usuario:</strong> <?php echo e($user->name); ?></p>
    <div class="divider"></div>
        <div id="basic-form" class="section">
            <div class="row">
                <div class="col s12 m8">
                    <div class="card">
                            <div class="card-content">
                                <h4 class="card-title"><?php echo e($user->name); ?></h4>
                                <p><strong>Edad: </strong><?php echo e($user->age()); ?></p>
                                <h5>Roles: </h5>
                                <ul>
                                    <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><i class='material-icons'>check</i><?php echo e($role->name); ?></li>
                                    <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul>
                                            <li><?php echo e($permission->name); ?></li>
                                        </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                                <div class="card-action">
                                    <a href="<?php echo e(route('backoffice.user.edit', $user)); ?>">Editar</a>
                                    <a href="#" style="color: red" onclick="enviar_formulario()">Eliminar</a>
                                </div>
                    </div>
                </div>

            
                        <div class="col s12 m4">
                        <?php echo $__env->make('themes.backoffice.pages.user.includes.user_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

        </div>
        </div>
    </div>
</div>

<form method="post" action="<?php echo e(route('backoffice.user.destroy', $user)); ?> " name="delete_form">
<?php echo e(csrf_field()); ?>

<?php echo e(method_field('DELETE')); ?>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<script>
 function enviar_formulario()
 {
     Swal.fire({
         title: "¿Deseas eliminar este usuario?",
         text: "Esta acción no se puede deshacer",
         type: "warning",
         showCancelButton: true,
         confirmButtonText: "Si, continuar",
         cancelButtonText: "No, cancelar",
         closeOnCancel: false,
         closeOnConfirm: true
     }).then((result)=> {
         if(result.value){
             document.delete_form.submit();
         }else{
             Swal.fire(
                 'Operación Cancelada',
                 'Registro no eliminado',
                 'error'
             )
         }
     });
 }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/user/show.blade.php ENDPATH**/ ?>