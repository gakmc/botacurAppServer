<?php $__env->startSection('title', 'Visitas'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
    <p class="caption"><strong>Visitas</strong></p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="row">
            <div class="col s12 ">


                <div class="card-panel">

                    <div class="row">
                        <div class="card-title">
                            <h4>Hoy</h4>
                        </div>
                        <?php $__empty_1 = true; $__currentLoopData = $reservasHoy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($reserva->visitas->isNotEmpty()): ?>
                        <?php $__currentLoopData = $reserva->visitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        


                        <div class="col s12 m12 l3">
                            <div id="flight-card" class="card">
                                <div class="card-header deep-orange accent-2">
                                    <div class="card-title">
                                        <h4 class="flight-card-title"><?php echo e($reserva->cliente->nombre_cliente); ?></h4>
                                        <p class="flight-card-date"><?php echo e($reserva->fecha_visita); ?></p>
                                    </div>
                                </div>
                                <div class="card-content-bg white-text">
                                    <div class="card-content">
                                        <div class="row flight-state-wrapper">
                                            <div class="col s3 m3 l3 center-align">
                                                <div class="flight-state">
                                                    <h4 class="margin">Sauna</h4>
                                                </div>
                                            </div>
                                            <div class="col s1 m1 l1 center-align">
                                                
                                            </div>
                                            <div class="col s3 m3 l3 center-align">
                                                <div class="flight-state">
                                                    <h4 class="margin">Tinaja</h4>
                                                </div>
                                            </div>
                                            <div class="col s1 m1 l1 center-align">
                                                
                                            </div>
                                            <div class="col s3 m3 l3 center-align">
                                                <div class="flight-state">
                                                    <h4 class="margin">Masaje</h4>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col s4 m4 l4 center-align">
                                                <div class="flight-info">
                                                    <p class="small">
                                                        <span class="white-text text-lighten-4">Inicio:</span><?php echo e($visita->horario_sauna); ?>

                                                    </p>
                                                    <p class="small">
                                                        <span class="white-text text-lighten-4">Fin:</span><?php echo e($visita->hora_fin_sauna); ?>

                                                    </p>
                                                    
                                                </div>
                                            </div>
                                            <div class="col s4 m4 l4 center-align flight-state-two">
                                                <div class="flight-info">
                                                    <p class="small">
                                                        <span class="white-text text-lighten-4">Inicio:</span><?php echo e($visita->horario_tinaja); ?>

                                                    </p>
                                                    <p class="small">
                                                        <span class="white-text text-lighten-4">Fin:</span><?php echo e($visita->hora_fin_tinaja); ?>

                                                    </p>
                                                    
                                                </div>
                                            </div>
                                            <div class="col s4 m4 l4 center-align flight-state-two">
                                                <div class="flight-info">
                                                    <p class="small">
                                                        <span class="white-text text-lighten-4">Inicio:</span><?php echo e($visita->horario_masaje); ?>

                                                    </p>
                                                    <p class="small">
                                                        <span class="white-text text-lighten-4">Fin:</span><?php echo e($visita->hora_fin_masaje); ?>

                                                    </p>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <p>No hay visitas registradas</p>
                            <?php endif; ?>


                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">No hay Reservas para hoy</td>
                        </tr>
                        <?php endif; ?>

                    </div>
                </div>


                <div class="card-panel">
                    <div class="row">
                        <div class="card-title">
                            <h4>Mañana</h4>
                        </div>

                        <?php $__empty_1 = true; $__currentLoopData = $reservasManana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($reserva->visitas->isNotEmpty()): ?>
                        <?php $__currentLoopData = $reserva->visitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        

                        <div class="col s12 m12 l3">
                            <div id="flight-card" class="card">
                                <div class="card-header deep-orange accent-2">
                                    <div class="card-title">
                                        <h4 class="flight-card-title"><?php echo e($reserva->cliente->nombre_cliente); ?></h4>
                                        <p class="flight-card-date"><?php echo e($reserva->fecha_visita); ?>, Thu 04:50</p>
                                    </div>
                                </div>
                                <div class="card-content-bg white-text">
                                    <div class="card-content">
                                        <div class="row flight-state-wrapper">
                                            <div class="col s3 m3 l3 center-align">
                                                <div class="flight-state">
                                                    <h4 class="margin">Hora</h4>
                                                    <p class="ultra-small">Sauna</p>
                                                </div>
                                            </div>
                                            <div class="col s1 m1 l1 center-align">
                                                <i class="material-icons flight-icon">local_airport</i>
                                            </div>
                                            <div class="col s3 m3 l3 center-align">
                                                <div class="flight-state">
                                                    <h4 class="margin">Hora</h4>
                                                    <p class="ultra-small">Tinaja</p>
                                                </div>
                                            </div>
                                            <div class="col s1 m1 l1 center-align">
                                                <i class="material-icons flight-icon">local_airport</i>
                                            </div>
                                            <div class="col s3 m3 l3 center-align">
                                                <div class="flight-state">
                                                    <h4 class="margin">SFO</h4>
                                                    <p class="ultra-small">San Francisco</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col s4 m4 l4 center-align">
                                                <div class="flight-info">
                                                    <p class="small">
                                                        <span class="grey-text text-lighten-4">Depart:</span> 04.50
                                                    </p>
                                                    <p class="small">
                                                        <span class="grey-text text-lighten-4">Flight:</span> IB 5784
                                                    </p>
                                                    <p class="small">
                                                        <span class="grey-text text-lighten-4">Terminal:</span> B
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="col s4 m4 l4 center-align flight-state-two">
                                                <div class="flight-info">
                                                    <p class="small">
                                                        <span class="grey-text text-lighten-4">Arrive:</span> 08.50
                                                    </p>
                                                    <p class="small">
                                                        <span class="grey-text text-lighten-4">Flight:</span> IB 5784
                                                    </p>
                                                    <p class="small">
                                                        <span class="grey-text text-lighten-4">Terminal:</span> C
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="col s4 m4 l4 center-align flight-state-two">
                                                <div class="flight-info">
                                                    <p class="small">
                                                        <span class="grey-text text-lighten-4">Arrive:</span> 08.50
                                                    </p>
                                                    <p class="small">
                                                        <span class="grey-text text-lighten-4">Flight:</span> IB
                                                        5786
                                                    </p>
                                                    <p class="small">
                                                        <span class="grey-text text-lighten-4">Terminal:</span> C
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>



                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <p>No hay visitas registradas</p>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">No hay reservas para hoy</td>
                        </tr>
                        <?php endif; ?>

                    </div>
                </div>



            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('foot'); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/visita/index.blade.php ENDPATH**/ ?>