
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1" name="viewport">
<meta content="IE=edge" http-equiv="X-UA-Compatible">
<meta content="no" name="msapplication-tap-highlight">


<link href="<?php echo e(asset('assents/backoffice/css/materialize.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assents/backoffice/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assents/backoffice/css/custom.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assents/plugins/perfect-scrollbar/perfect-scrollbar.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assents/plugins/flag-icon/css/flag-icon.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/animate/animate.min.css')); ?>" rel="stylesheet">

<?php echo $__env->yieldContent('head'); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/layouts/includes/head.blade.php ENDPATH**/ ?>