<div class="collection">

    <a href=""  class="collection-item active" ><h5>Reagendamiento:</h5></a>


        <?php if($reserva->reagendamientos->isEmpty()): ?>
            <a class="collection-item center">Esta reserva no posee reagendamientos. </a>
            <a href="<?php echo e(route('backoffice.reserva.reagendamientos.create', $reserva)); ?>" class="btn-floating activator btn-move-up waves-effect waves-light accent-2 z-depth-0 right"> <i class="material-icons">update</i> </a>

        <?php else: ?>
            <?php $__currentLoopData = $reserva->reagendamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reagendamiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="collection-item center-align valign-wrapper"><?php echo e($reagendamiento->fecha_original); ?> <span><i class="material-icons">arrow_forward</i></span> <?php echo e($reagendamiento->nueva_fecha); ?></a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('backoffice.reserva.reagendamientos.create', $reserva)); ?>" class="btn-floating activator btn-move-up waves-effect waves-light accent-2 z-depth-0 right"> <i class="material-icons">update</i> </a>
        <?php endif; ?>


    
 
 </div><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/reserva/includes/reagendamiento.blade.php ENDPATH**/ ?>