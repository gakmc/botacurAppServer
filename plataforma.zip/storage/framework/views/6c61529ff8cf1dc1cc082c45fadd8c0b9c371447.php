<?php $__env->startSection('title','Usuarios del Sistema'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.user.index')); ?>">Usuarios del Sistema</a></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dropdown_settings'); ?>
<li><a href="<?php echo e(route ('backoffice.user.create')); ?>" class="grey-text text-darken-2">Crear Usuario</a></li> 
<!-- <li><a href="" class="grey-text text-darken-2">Crear Usuario</a></li> -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="section">
              <p class="caption"><strong>Usuarios del Sistema</strong></p>
              <div class="divider"></div>
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 ">
                    <div class="card-panel">
                     
                      <div class="row">


                      <table>
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Edad</th>
                                    <th>Correo</th>
                                    <th colspan="2">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><a href="<?php echo e(route('backoffice.user.show' ,$user )); ?>"><?php echo e($user->name); ?></a></td>
                                  <td><?php echo e($user->age()); ?></td>
                                  <td><?php echo e($user->email); ?></td>
                                  
                                  <td><a href="<?php echo e(route('backoffice.user.edit', $user )); ?>">Editar</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/user/index.blade.php ENDPATH**/ ?>