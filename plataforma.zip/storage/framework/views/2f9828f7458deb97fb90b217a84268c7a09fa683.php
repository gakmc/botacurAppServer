<?php $__env->startSection('title','Reagendar reserva'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.reserva.show', $reserva)); ?>">Reagendamiento para reserva del cliente</a></li>
<li>Crear Reagendamiento</li>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="section">
              <p class="caption">Introduce los datos para crear un nuevo reserva</p>
              <div class="divider"></div>
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 m8 offset-m2 ">
                    <div class="card-panel">
                      <h4 class="header">Reagendar reserva para <strong><?php echo e($reserva->cliente->nombre_cliente); ?></strong></h4>
                      <div class="row">
                        <form class="col s12" method="post" action="<?php echo e(route('backoffice.reserva.reagendamientos.store', $reserva)); ?>">


                        <?php echo e(csrf_field()); ?>

 
                            

                            <div class="row">
                                <div class="input-field col s12">
                                <input id="id_reserva" type="hidden" class="form-control" name="id_reserva" value="<?php echo e($reserva->id); ?>" required>

                                <p>Fecha Nueva Visita: </p>
                                
                                  <input id="nueva_fecha" type="date" name="nueva_fecha" class="" value="<?php echo e(old('nueva_fecha')); ?>" placeholder="fecha Visita">
                                    <?php $__errorArgs = ['nueva_fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong style="color:red"><?php echo e($message); ?></strong>
                                          </span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                




                                </div>


                            </div>     



                         


                          <div class="row">
                              <div class="input-field col s12">
                                <button class="btn waves-effect waves-light right" type="submit">Guardar
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/reagendamiento/create.blade.php ENDPATH**/ ?>