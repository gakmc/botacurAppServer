<?php $__env->startSection('title','Programas Botacura'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dropdown_settings'); ?>
<li><a href="<?php echo e(route ('backoffice.servicio.create')); ?>" class="grey-text text-darken-2">Crear Servicio</a></li> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
              <p class="caption"><strong>Programas de Temporada</strong></p>
              <div class="divider"></div>
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 ">
                    <div class="card-panel">
                     
                      <div class="row">


                      <table>
                            <thead>
                                <tr>
                                    <th>Nombre Servicio	</th>
                                    <th>Valor Servicio</th>
                                    <th>Costo Servicio</th>
                                    <th>Duración</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route ('backoffice.servicio.show',$servicio)); ?>"><?php echo e($servicio->nombre_servicio); ?></a></td>
                                    <td><?php echo e($servicio->valor_servicio); ?></td>
                                    <td><?php echo e($servicio->costo_servicio); ?></td>
                                    <td><?php echo e($servicio->duracion); ?></td>
                                    <td><a href="<?php echo e(route ('backoffice.servicio.edit',$servicio)); ?>">Editar</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                    </table>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/servicio/index.blade.php ENDPATH**/ ?>