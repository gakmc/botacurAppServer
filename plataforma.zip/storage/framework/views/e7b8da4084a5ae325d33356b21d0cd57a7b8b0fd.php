<?php $__env->startSection('title','Productos'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.producto.index')); ?>">Productos</a></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dropdown_settings'); ?>
<li><a href="<?php echo e(route ('backoffice.producto.create')); ?>" class="grey-text text-darken-2">Crear Producto</a></li>
<!-- <li><a href="" class="grey-text text-darken-2">Crear Usuario</a></li> -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="section">
    <p class="caption"><strong>Productos</strong></p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="row">
            <div class="col s12 ">
                <div class="card-panel">

                    <div class="row">

                        <?php if($productos->isNotEmpty()): ?>


                        <table>
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Valor</th>
                                    <th>Tipo de Producto</th>
                                    
                                    <th colspan="2">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a
                                            href="<?php echo e(route('backoffice.producto.show' ,$producto )); ?>"><?php echo e($producto->nombre); ?></a>
                                    </td>
                                    <td><?php echo e($producto->valor); ?></td>
                                    <td><?php echo e($producto->tipoProducto->nombre); ?></td>

                                    <td><a href="<?php echo e(route('backoffice.producto.edit', $producto )); ?>"><i
                                                class="material-icons">mode_edit</i> Editar</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <?php else: ?>
                            <h5>No se registran productos</h5>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/producto/index.blade.php ENDPATH**/ ?>