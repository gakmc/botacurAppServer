<div id="loader-wrapper">
    <div id="loader">
    </div>
    <div class="loader-section section-left">
    </div>
    <div class="loader-section section-right">
    </div>
</div><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/layouts/includes/loader.blade.php ENDPATH**/ ?>