<div class="collection">

    <a href="<?php echo e(route('backoffice.cliente.show', $cliente)); ?>"  class="collection-item active" ><h5>Reservas:</h5></a>


        <?php if($cliente->reservas->isEmpty()): ?>
            <a class="collection-item center">Este cliente no tiene reservas. </a>
            <a href="<?php echo e(route('backoffice.reserva.create', $cliente->id)); ?>" class="btn-floating activator btn-move-up waves-effect waves-light accent-2 z-depth-0 right"> <i class="material-icons">add</i> </a>

        <?php else: ?>
            <?php $__currentLoopData = $cliente->reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="collection-item center-align valign-wrapper center" style="display: flex; justify-content:space-between;">

                <a href="#modal-reserva<?php echo e($reserva->id); ?>" class="modal-trigger center-align valign-wrapper"
                    <?php if($reserva->venta->total_pagar <= 0): ?>
                        style="color:green;"
                    <?php else: ?>
                        style="color:#FF4081;"
                    <?php endif; ?> 
                    data-id="<?php echo e($reserva->id); ?>" 
                    data-cliente="<?php echo e($cliente->nombre_cliente); ?>" 
                    data-fecha="<?php echo e($reserva->fecha_visita); ?>" 
                    data-observacion="<?php echo e($reserva->observacion); ?>"
                    data-masaje="<?php echo e($reserva->cantidad_masajes); ?>"
                    data-personas="<?php echo e($reserva->cantidad_personas); ?>"
                    >Visita: <?php echo e($reserva->fecha_visita); ?></a>

                <div style="display: flex; justify-content:space-between;">

                    <a href="<?php echo e(route('backoffice.cliente.pdf', $reserva)); ?>" target="_blank" class="collection-item" style="cursor: pointer"><i class='material-icons tooltipped' data-position="bottom" data-tooltip="Ver PDF">picture_as_pdf</i></a>

                    <a class="collection-item" style="cursor: pointer"><i class='material-icons tooltipped' data-position="bottom" data-tooltip="Ver PDF">file_download</i></a>

                </div>
                
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('backoffice.reserva.create', $cliente->id)); ?>" class="btn-floating activator btn-move-up waves-effect waves-light accent-2 z-depth-0 right"> <i class="material-icons">add</i> </a>
        <?php endif; ?>


    
 
 </div><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/cliente/includes/cliente_nav.blade.php ENDPATH**/ ?>