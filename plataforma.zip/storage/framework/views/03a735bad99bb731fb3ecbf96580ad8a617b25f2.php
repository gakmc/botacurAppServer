<div class="collection">

    
   <a href="<?php echo e(route('backoffice.user.show', $user)); ?>"  class="collection-item active" ><?php echo e($user->name); ?></a>
   <a href="<?php echo e(route('backoffice.user.assign_role', $user)); ?>" class="collection-item">Asignar Roles</a> 
   <a href="<?php echo e(route('backoffice.user.assign_permission', $user)); ?>" class="collection-item">Asignar Permisos</a> 
   

</div><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/user/includes/user_nav.blade.php ENDPATH**/ ?>