<?php $__env->startSection('title','Crear reserva'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.cliente.show', $cliente->id)); ?>">Reservas del cliente</a></li>
<li>Crear Reserva</li>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="section">
  <p class="caption">Introduce los datos para crear un nuevo reserva</p>
  <div class="divider"></div>
  <div id="basic-form" class="section">
    <div class="row">
      <div class="col s12 m8 offset-m2 ">
        <div class="card-panel">
          <h4 class="header">Crear reserva para <strong><?php echo e($cliente->nombre_cliente); ?></strong></h4>
          <div class="row">
            <form class="col s12" method="post" enctype="multipart/form-data"
              action="<?php echo e(route('backoffice.reserva.store')); ?>">


              <?php echo e(csrf_field()); ?>




              <div class="row">
                <div class="input-field col s12 m6">

                  <select name="id_programa" id="id_programa">
                    <option value="" disabled selected>-- Seleccione un programa --</option>
                    <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($programa->id); ?>" <?php if(old('id_programa')==$programa->id): ?>
                      selected
                      <?php else: ?>

                      <?php endif; ?> data-valor="<?php echo e($programa->valor_programa); ?>"
                      data-incluye-masajes="<?php echo e($programa->incluye_masajes ? '1' : '0'); ?>"
                      ><?php echo e($programa->nombre_programa); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <label for="id_programa">Programa</label>
                  <?php $__errorArgs = ['id_programa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong style="color:red"><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>



                <div class="input-field col s12 m6">
                  <input id="cliente_id" type="hidden" class="form-control" name="cliente_id" value="<?php echo e($cliente->id); ?>"
                    required>


                  <label for="cantidad_personas">Cantidad Personas</label>

                  <input id="cantidad_personas" type="number"
                    class="form-control <?php $__errorArgs = ['cantidad_personas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cantidad_personas"
                    value="<?php echo e(old('cantidad_personas')); ?>" required>
                  <?php $__errorArgs = ['cantidad_personas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong style="color:red"><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>





              </div>


              <div class="row">

                <div class="input-field col s12 m3">

                  <label for="abono_programa">Cantidad de Abono</label>
                  <input id="abono_programa" type="text" name="abono_programa" class=""
                    value="<?php echo e(old('abono_programa')); ?>">
                  <?php $__errorArgs = ['abono_programa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong style="color:red"><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="file-field input-field col s12 m5">
                  <div class="btn">
                    <span>Imagen Abono</span>
                    <input type="file" id="imagen_abono" name="imagen_abono">
                  </div>
                  <div class="file-path-wrapper">
                    <input class="file-path validate" type="text" placeholder="Seleccione su archivo">
                  </div>
                  <?php $__errorArgs = ['imagen_abono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong style="color:red"><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="input-field col s12 m4">
                  <select id="tipo_transaccion" name="tipo_transaccion">
                    <option disabled selected>-- Seleccione --</option>
                    <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($tipo->id); ?>" <?php if(old('tipo_transaccion')==$tipo->id): ?> selected <?php endif; ?>>
                      <?php echo e($tipo->nombre); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php $__errorArgs = ['tipo_transaccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong style="color:red"><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <label for="tipo_transaccion">Tipo Transacción Abono</label>
                </div>

              </div>



              <div class="row">
                <div class="input-field col s12 m3">
                  <label for="fecha_visita">Fecha Visita</label>
                  <input id="fecha_visita" type="date" name="fecha_visita" class="" value="<?php echo e(old('fecha_visita')); ?>"
                    placeholder="fecha Visita">
                  <?php $__errorArgs = ['fecha_visita'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong style="color:red"><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="input-field col s12 m3">
                  <input id="observacion" name="observacion" type="text" class="" value="<?php echo e(old('observacion')); ?>" />
                  <label for="observacion">Observaciones</label>
                  <?php $__errorArgs = ['observacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong style="color:red"><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>



                <label id="checkbox-masajes-container" class="input-field col s12 m3">
                  <input style="display: none" type="checkbox" id="agregar_masajes" name="agregar_masajes" />
                  <span>¿Desea agregar masajes?</span>
                </label>


                <div class="input-field col s12 m3" id="input-cantidad-masajes-container">
                  <input id="cantidad_masajes_extra" type="number" name="cantidad_masajes_extra"
                    value="<?php echo e(old('cantidad_masajes_extra')); ?>">
                  <label for="cantidad_masajes_extra">Cantidad masajes extras</label>
                  <?php $__errorArgs = ['cantidad_masajes_extra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong style="color:red"><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>




              </div>

              <div class="row">
                <div class="input-field col s12 m3">

                  <label for="total_pagar">Total a pagar</label>
                  <input id="total_pagar" type="number" name="total_pagar" class="" value="<?php echo e(old('total_pagar')); ?>"
                    placeholder="0" readonly>
                  <?php $__errorArgs = ['total_pagar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong style="color:red"><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="input-field col s12 m6">
                  <label for="imagenSeleccionadaAbono">Imagen Abono:</label>
                  <img class="center-text" id="imagenSeleccionadaAbono" src="https://via.placeholder.com/200x300" alt=""
                    style="max-height: 200px">
                </div>
              </div>








              <div class="row">
                <div class="input-field col s12">
                  <button class="btn waves-effect waves-light right" type="submit">Guardar
                    <i class="material-icons right">send</i>
                  </button>
                </div>
              </div>


            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>
<script>
  $(document).ready(function (e) {   
  $('#imagen_abono').change(function(){            
      let reader = new FileReader();
      reader.onload = (e) => { 
          $('#imagenSeleccionadaAbono').attr('src', e.target.result); 
      }
      reader.readAsDataURL(this.files[0]);
  });
});


$(document).ready(function (e) {   
  $('#imagen_diferencia').change(function(){            
      let reader = new FileReader();
      reader.onload = (e) => { 
          $('#imagenSeleccionadaDiferencia').attr('src', e.target.result); 
      }
      reader.readAsDataURL(this.files[0]);
  });
});
</script>

<script>
  var valorPrograma = 0;
  var cantidadPersonas = 1;
  var abono = 0;

$('#id_programa').on('change', function(){
  valorPrograma = $(this).find(':selected').data('valor');
  calcularValorTotal();
});

$('#cantidad_personas').on('change', function(){
  cantidadPersonas = $(this).val();
  calcularValorTotal();
})

$('#abono_programa').on('change', function(){
  abono = $(this).val();
  calcularValorTotal();
})

function calcularValorTotal(){

  var total = (valorPrograma * cantidadPersonas)-abono;
  $('#total_pagar').val(total);
}

</script>


<script>
  $(document).ready(function(e){
  const selectPrograma = $('#id_programa');
  const cantidadMasajesInput = $('#cantidad_masajes').closest('div');
  const checkboxMasajesContainer = $('#checkbox-masajes-container');
  const inputCantidadMasajesContainer = $('#input-cantidad-masajes-container');
  const agregarMasajesCheckbox = $('#agregar_masajes');
  const cantidadMasajesExtraInput = $('#cantidad_masajes_extra');


  function toggleMasajesField() {
    const selectedOption = selectPrograma.find('option:selected');
    const incluyeMasajes = selectedOption.data('incluye-masajes');
    const inputMasajes = $('#cantidad_masajes');
    
    if (incluyeMasajes === 1) {
      // Si el programa incluye masajes, mostramos el input normal de cantidad de masajes
      cantidadMasajesInput.show();
      checkboxMasajesContainer.hide(); // Ocultar el checkbox de agregar masajes extras
      inputCantidadMasajesContainer.hide(); // Ocultar el input de cantidad de masajes extras
      cantidadMasajesExtraInput.val('');
      agregarMasajesCheckbox.prop('checked', false);
      inputMasajes.val('');
    } else {
      // Si no incluye masajes, ocultamos el input normal de masajes y mostramos el checkbox para agregar masajes extras
      cantidadMasajesInput.hide();
      checkboxMasajesContainer.show(); // Mostrar checkbox para agregar masajes
      inputCantidadMasajesContainer.hide(); // Inicialmente ocultamos el input de cantidad de masajes extras
      cantidadMasajesExtraInput.val('');
      agregarMasajesCheckbox.prop('checked', false);
      inputMasajes.val('');
    }
  }

  // Mostrar el input de cantidad de masajes solo si el checkbox está marcado
  agregarMasajesCheckbox.on('change', function() {
    if ($(this).is(':checked')) {
      inputCantidadMasajesContainer.show(); // Mostrar el input de cantidad si el checkbox está marcado
    } else {
      inputCantidadMasajesContainer.hide(); // Ocultar el input si el checkbox está desmarcado
      cantidadMasajesExtraInput.val('');
    }
  });

  // Escucha el evento change del select para detectar cuando cambie
  selectPrograma.on('change', toggleMasajesField);

  // Inicializa el estado del campo en la carga de la página
  toggleMasajesField(); // Para verificar la selección inicial
  
});


</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/reserva/create.blade.php ENDPATH**/ ?>