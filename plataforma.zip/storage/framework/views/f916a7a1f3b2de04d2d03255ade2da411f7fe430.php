<?php $__env->startSection('title','Panel de Administración'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li>Panel de Administración</li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dropdown_settings'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="section">
    <p class="caption"><strong>Panel de Administración</strong></p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="row">
            <div class="col s12 ">
                <div class="card-panel">
                    <div class="row">



                        
                        <div id="card-stats">
                            <div class="row mt-1">
                                <!-- Tarjeta para mostrar el número de Reservas -->
                                <div class="col s12 m6 l3">
                                    <div class="animate__animated animate__backInLeft card gradient-45deg-light-blue-cyan gradient-shadow min-height-100 white-text"
                                        style="--animate-delay: 1s; --animate-duration: 2s; ">
                                        <div class="padding-4">
                                            <div class="col s7 m7">
                                                <i class="material-icons background-round mt-5">assignment</i>
                                                <p>Reservas</p>
                                            </div>
                                            <div class="col s5 m5 right-align">
                                                <h5 id="reservas-count" class="mb-0"><?php echo e($totalReservas); ?></h5>
                                                <p class="no-margin">Total</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Tarjeta para mostrar el número de Clientes -->
                                <div class="col s12 m6 l3">
                                    <div class="animate__animated animate__backInLeft card gradient-45deg-red-pink gradient-shadow min-height-100 white-text"
                                        style="--animate-delay: 1s; --animate-duration: 2s;">
                                        <div class="padding-4">
                                            <div class="col s7 m7">
                                                <i class="material-icons background-round mt-5">airport_shuttle</i>
                                                <p>Clientes</p>
                                            </div>
                                            <div class="col s5 m5 right-align">
                                                <h5 id="clientes-count" class="mb-0"><?php echo e($totalClientes); ?></h5>
                                                <p class="no-margin">Total</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                                <!-- Tarjeta para mostrar el número de Clientes -->
                                <div class="col s12 m6 l3">
                                    <a href="<?php echo e(route('backoffice.admin.index')); ?>">
                                        <div class="animate__animated animate__backInLeft card gradient-45deg-green-teal gradient-shadow min-height-100 white-text"
                                            style="--animate-delay: 1s; --animate-duration: 2s;">
                                            <div class="padding-4">
                                                <div class="col s7 m7">
                                                    <i class="material-icons background-round mt-5">spa</i>
                                                    <p>Masajes Asignados</p>
                                                </div>
                                                <div class="col s5 m5 right-align">
                                                    <h5 id="clientes-count" class="mb-0"><?php echo e($masajesAsignados); ?></h5>
                                                    <p class="no-margin">Total</p>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>


                                

                            </div>
                        </div>






                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>
<script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/countup.js/1.9.3/countUp.min.js">
</script>
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
    // Asegurar que los valores se conviertan correctamente en números
    var totalReservas = parseInt("<?php echo e($totalReservas); ?>", 10) || 0;
    var totalClientes = parseInt("<?php echo e($totalClientes); ?>", 10) || 0;


    // Inicializar el conteo para reservas
    var reservasCountUp = new CountUp('reservas-count',0, totalReservas);
    if (!reservasCountUp.error) {
        reservasCountUp.start();
    } else {
        console.error(reservasCountUp.error);
    }

    // Inicializar el conteo para clientes
    var clientesCountUp = new CountUp('clientes-count',0, totalClientes);
    if (!clientesCountUp.error) {
        clientesCountUp.start();
    } else {
        console.error(clientesCountUp.error);
    }
});

</script>


<?php if($insumosCriticos->isNotEmpty()): ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        Swal.fire({
            title: 'Stock Crítico',
            icon: 'error',
            html: `
                <ul>
                    <?php $__currentLoopData = $insumosCriticos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($insumo->nombre); ?>: <?php echo e($insumo->cantidad); ?> unidades (Stock crítico: <?php echo e($insumo->stock_critico); ?>)</li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            `,
            confirmButtonText: 'Aceptar',
        });
    });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/admin/show.blade.php ENDPATH**/ ?>