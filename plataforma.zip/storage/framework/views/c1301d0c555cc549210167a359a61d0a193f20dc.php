<?php $__env->startSection('title', $cliente->nombre_cliente); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.cliente.index')); ?>">Clientes del Sistema</a></li>
<li><?php echo e($cliente->nombre_cliente); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dropdown_settings'); ?>
<li><a href="<?php echo e(route('backoffice.reserva.create',$cliente->id)); ?>" class="grey-text text-darken-2">Crear Reserva</a>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
    <p class="caption"><strong>Cliente:</strong> <?php echo e($cliente->nombre_cliente); ?></p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="row">
            <div class="col s12 m8">
                <div class="card">
                    <div class="card-content">



                        <span class="card-title activator grey-text text-darken-4"><?php echo e($cliente->nombre_cliente); ?></span>
                        <p>
                            <?php if(is_null($cliente->whatsapp_cliente)): ?>
                            <i class="material-icons">perm_phone_msg</i> No Registra
                            <?php else: ?>
                            <i class="material-icons">perm_phone_msg</i> <a
                                href="https://api.whatsapp.com/send?phone=<?php echo e($cliente->whatsapp_cliente); ?>"
                                target="_blank">+<?php echo e($cliente->whatsapp_cliente); ?></a>
                            <?php endif; ?>

                        </p>
                        <p>

                            <?php if(is_null($cliente->instagram_cliente)): ?>
                            <i class="material-icons">perm_identity</i> No Registra
                            <?php else: ?>
                            <i class="material-icons">perm_identity</i> <a
                                href="https://www.instagram.com/<?php echo e($cliente->instagram_cliente); ?>"
                                target="_blank"><?php echo e($cliente->instagram_cliente); ?></a>
                            <?php endif; ?>


                        </p>
                        <p>

                            <?php if(is_null($cliente->correo)): ?>
                            <i class="material-icons">email</i> No Registra
                            <?php else: ?>
                            <i class="material-icons">email</i> <a href="mailto:<?php echo e($cliente->correo); ?>"
                                target="_blank"><?php echo e($cliente->correo); ?></a>
                            <?php endif; ?>


                        </p>




                    </div>
                    <div class="card-action">
                        <a href="<?php echo e(route('backoffice.cliente.edit', $cliente)); ?>" class="purple-text">Editar</a>
                        
                    </div>
                </div>
            </div>


            <div class="col s12 m4">
                <?php echo $__env->make('themes.backoffice.pages.cliente.includes.cliente_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <?php echo $__env->make('themes.backoffice.pages.cliente.includes.modal_reserva', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        </div>
    </div>
</div>
</div>

<form method="post" action="<?php echo e(route('backoffice.cliente.destroy', $cliente)); ?> " name="delete_form">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('DELETE')); ?>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<script>
    function enviar_formulario()
 {
     Swal.fire({
         title: "¿Deseas eliminar este cliente?",
         text: "Esta acción no se puede deshacer",
         type: "warning",
         showCancelButton: true,
         confirmButtonText: "Si, continuar",
         cancelButtonText: "No, cancelar",
         closeOnCancel: false,
         closeOnConfirm: true
     }).then((result)=> {
         if(result.value){
             document.delete_form.submit();
         }else{
             Swal.fire(
                 'Operación Cancelada',
                 'Registro no eliminado',
                 'error'
             )
         }
     });
 }
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var elems = document.querySelectorAll('.modal');
        M.Modal.init(elems);
    });

    document.addEventListener('DOMContentLoaded', function() {
        var elems = document.querySelectorAll('.tooltipped');
        M.Modal.init(elems);
    });

</script>

<script>
    $(document).ready(function(){
  $('.modal-trigger').on('click', function(){
        // Obtener los datos del cliente y la reserva seleccionada
        var clienteNombre = $(this).data('cliente');
        var fechaReserva = $(this).data('fecha');
        var observacionReserva = $(this).data('observacion');
        var masajeReserva = $(this).data('masaje');
        var personasReserva = $(this).data('personas');

        // Insertar los datos en los elementos del modal
        $('#modalClienteNombre').text(clienteNombre);
        $('#modalFechaReserva').text(fechaReserva);
        $('#modalObservacionReserva').text(observacionReserva);
        $('#modalMasajeReserva').text(masajeReserva);
        $('#modalPersonasReserva').text(personasReserva);

    // Abrir el modal
    var modal = M.Modal.getInstance($('#modalReserva'));
    modal.open();
  });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/cliente/show.blade.php ENDPATH**/ ?>