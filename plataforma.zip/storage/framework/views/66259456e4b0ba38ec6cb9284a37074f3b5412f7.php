<?php $__env->startSection('title','Editar ' . $user->name); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.user.index')); ?>">Usuario del sistema</a></li>
<li>Editar <?php echo e($user->name); ?></li>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="section">
              <p class="caption">Actualiza los datos del usuario</p>
              <div class="divider"></div>
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 m8 offset-m2 ">
                    <div class="card-panel">
                      <h4 class="header2">Editar Usuario</h4>
                      <div class="row">
                        <form class="col s12" method="post" action="<?php echo e(route('backoffice.user.update', $user)); ?>">


                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

    
                            

                            <div class="row">
                                <div class="input-field col s12">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e($user->name); ?>" required autocomplete="name" autofocus>
                                    <label for="name">Nombre del Usuario</label>

                                    <?php if($errors->has('name')): ?>
                                        <!-- <div class="alert alert-danger"><?php echo e($messages ?? ''); ?></div> -->

                                        <span class="invalid-feedback" role="alert">
                                            <strong style="color: red"><?php echo e($errors->first('name')); ?></strong>
                                        </span>

                                    <?php endif; ?>

                                </div>
                            </div>     

                         
                          <div class="row">
                            <div class="input-field col s12">
                              <input id="dob" type="date" name="dob" value="<?php echo e($user->dob); ?>">
                                <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="invalid-feedback" role="alert">
                                          <strong style="color:red"><?php echo e($message); ?></strong>
                                      </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                         

                          <div class="row">
                            <div class="input-field col s12">
                              <input id="email" type="email" name="email" value="<?php echo e($user->email); ?>">
                              <label for="email">Correo electrónico</label>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="invalid-feedback" role="alert">
                                          <strong style="color:red"><?php echo e($message); ?></strong>
                                      </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                         
                       


                          <div class="row">
                              <div class="input-field col s12">
                                <button class="btn waves-effect waves-light right" type="submit">Actualizar
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/user/edit.blade.php ENDPATH**/ ?>