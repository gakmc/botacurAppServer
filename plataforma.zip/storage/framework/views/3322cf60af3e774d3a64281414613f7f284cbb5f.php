<!DOCTYPE html>
<html lang="es">
    <head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <?php echo $__env->make('themes.backoffice.layouts.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
        <?php echo $__env->make('themes.backoffice.layouts.includes.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('themes.backoffice.layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="main">
            <div class="wrapper">
                <?php echo $__env->make('themes.backoffice.layouts.includes.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <section id="content">
                    <?php echo $__env->make('themes.backoffice.layouts.includes.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="container">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>

                    
                </section>
            </div>
        </div>

        <?php echo $__env->make('themes.backoffice.layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <?php echo $__env->make('themes.backoffice.layouts.includes.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('foot'); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/layouts/admin.blade.php ENDPATH**/ ?>