<?php $__env->startSection('title','Panel de Administración'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li>Masajes Asignados</li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dropdown_settings'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="section">
    <p class="caption"><strong>Masajes</strong></p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="row">
            <div class="col s12 ">
                <div class="card-panel">
                    <div class="row">



                        

                        <div class="col s12">
                            <div class="card">
                                <div class="card-content blue white-text">
                                    <h5 id="titulo"></h5>
                                </div>
                                <div class="card-tabs">
                                    <ul class="tabs tabs-fixed-width">
                                        <?php $__currentLoopData = $masoterapeutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $masoterapeuta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="tab"><a id="seleccion" href="#masoterapeuta-<?php echo e($masoterapeuta->id); ?>"><?php echo e($masoterapeuta->name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <div class="card-content grey lighten-4">
                                    <?php $__currentLoopData = $masoterapeutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $masoterapeuta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div id="masoterapeuta-<?php echo e($masoterapeuta->id); ?>">
                                            <p><strong>Total de esta Semana: <?php echo e($cantidadMasajesPorSemana[$masoterapeuta->id]); ?></strong></p>
                        
                                            <h6>Masajes Realizados por Día</h6>
                                            <ul>
                                                <?php $__currentLoopData = $cantidadMasajesPorDia[$masoterapeuta->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia => $cantidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($dia); ?>: <?php echo e($cantidad); ?> masajes</li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>






                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>
<script>
$(document).ready(function () {
    let seleccion = $('#seleccion').text();

    let nombreInicial = $('.tabs .tab a.active').text();
    if (!nombreInicial) {
        nombreInicial = $('.tabs .tab a:first').text();
    }
    $('#titulo').text(nombreInicial);

    $('.tabs .tab a').on('click',function(e){
        e.preventDefault();
        let nombreMaso = $(this).text();
        $('#titulo').text(nombreMaso);
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/admin/index.blade.php ENDPATH**/ ?>