<?php $__env->startSection('title','Programas Botacura'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dropdown_settings'); ?>
<li><a href="<?php echo e(route ('backoffice.programa.create')); ?>" class="grey-text text-darken-2">Crear Programa</a></li> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
              <p class="caption"><strong>Programas de Temporada</strong></p>
              <div class="divider"></div>
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 ">
                    <div class="card-panel">
                     
                      <div class="row">


                      <table>
                            <thead>
                                <tr>
                                    <th>Nombre Programa	</th>
                                    <th>Valor Programa</th>
                                    <th>Descuento</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $programa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route ('backoffice.programa.show',$programa)); ?>"><?php echo e($programa->nombre_programa); ?></a></td>
                                    <td><?php echo e($programa->valor_programa); ?></td>
                                    <td><?php echo e($programa->descuento); ?></td>
                                    <td><a href="<?php echo e(route ('backoffice.programa.edit',$programa)); ?>">Editar</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                    </table>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/programa/index.blade.php ENDPATH**/ ?>