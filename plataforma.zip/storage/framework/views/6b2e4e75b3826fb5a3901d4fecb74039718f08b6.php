<?php $__env->startSection('title','Dar de alta un nuevo usuario'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.user.index')); ?>">Usuario del sistema</a></li>
<li>Crear Usuario</li>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="section">
              <p class="caption">Introduce los datos para crear un nuevo usuario</p>
              <div class="divider"></div>
              <div id="basic-form" class="section">
                <div class="row">
                  <div class="col s12 m8 offset-m2 ">
                    <div class="card-panel">
                      <h4 class="header2">Crear Usuario</h4>
                      <div class="row">
                        <form class="col s12" method="post" action="<?php echo e(route('backoffice.user.store')); ?>">


                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                                <div class="input-field col s12">

                                    <select name="role" id="role" required="">

                                        <option value="" disabled="" selected="">-- Selecciona un Rol --</option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>


                                    <?php if($errors->has('role_id')): ?>
                                        <!-- <div class="alert alert-danger"><?php echo e($messages ?? ''); ?></div> -->

                                        <span class="invalid-feedback" role="alert">
                                            <strong style="color: red"><?php echo e($errors->first('role_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>


                                </div>
                            </div>     
                            

                            <div class="row">
                                <div class="input-field col s12">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                    <label for="name">Nombre del Usuario</label>

                                    <?php if($errors->has('name')): ?>
                                        <!-- <div class="alert alert-danger"><?php echo e($messages ?? ''); ?></div> -->

                                        <span class="invalid-feedback" role="alert">
                                            <strong style="color: red"><?php echo e($errors->first('name')); ?></strong>
                                        </span>

                                    <?php endif; ?>

                                </div>
                            </div>     

                         
                          <div class="row">
                            <div class="input-field col s12">
                              <input id="dob" type="date" name="dob">
                                <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="invalid-feedback" role="alert">
                                          <strong style="color:red"><?php echo e($message); ?></strong>
                                      </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                         

                          <div class="row">
                            <div class="input-field col s12">
                              <input id="email" type="email" name="email">
                              <label for="email">Correo electrónico</label>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="invalid-feedback" role="alert">
                                          <strong style="color:red"><?php echo e($message); ?></strong>
                                      </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                         
                        
                          <div class="row">
                            <div class="input-field col s12">
                              <input id="password" type="password" name="password">
                              <label for="password">Contraseña</label>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="invalid-feedback" role="alert">
                                          <strong style="color:red"><?php echo e($message); ?></strong>
                                      </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                         

                          <div class="row">
                            <div class="input-field col s12">
                              <input id="password_confirmation" type="password" name="password_confirmation">
                              <label for="password_confirmation">Confirmar contraseña</label>
                                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="invalid-feedback" role="alert">
                                          <strong style="color:red"><?php echo e($message); ?></strong>
                                      </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                         


                          <div class="row">
                              <div class="input-field col s12">
                                <button class="btn waves-effect waves-light right" type="submit">Guardar
                                  <i class="material-icons right">send</i>
                                </button>
                              </div>
                            </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/user/create.blade.php ENDPATH**/ ?>