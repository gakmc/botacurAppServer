<?php $__env->startSection('title', 'Masajes'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
    <p class="caption"><strong>Masajes <?php echo e(now()->format('d-m-Y')); ?></strong></p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="card-panel ">



            <table class="responsive-table">
                <thead>
                    <tr>
                        <th>Horario Masajes</th>
                        <th>Nombre Cliente</th>
                        <th>Cantidad Personas</th>
                        <th>Tipo Masajes</th>
                        <th>Lugar Masajes</th>
                        <th>Estado</th>
                        <th>Asignación</th>
                    </tr>
                </thead>
            
                <tbody>

                    <?php $__currentLoopData = $reservasHoy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha => $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $reserva->visitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!is_null($visita->horario_masaje)): ?>
                            <?php for($i = 1; $i <= $reserva->cantidad_personas; $i++): ?>
                                <tr>
                                    <td>
                                        <?php echo e($visita->horario_masaje); ?> -
                                        <?php if($visita->hora_fin_masaje): ?>
                                            <?php echo e($visita->hora_fin_masaje); ?>

                                        <?php else: ?>
                                            <?php echo e($visita->hora_fin_masaje_extra); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($reserva->cliente->nombre_cliente); ?></td>
                                    <td>Persona <?php echo e($i); ?></td>
                                    <td><?php echo e($visita->tipo_masaje); ?></td>
                                    <td><?php echo e($visita->lugarMasaje->nombre); ?></td>
                                    <td>
                                        <span class="estado badge white-text cyan" 
                                              data-inicio="<?php echo e($visita->horario_masaje); ?>"
                                              <?php if($visita->hora_fin_masaje): ?>
                                                  data-fin="<?php echo e($visita->hora_fin_masaje); ?>"
                                              <?php else: ?>
                                                  data-fin="<?php echo e($visita->hora_fin_masaje_extra); ?>"
                                              <?php endif; ?>
                                              ></span>
                                    </td>
                                    <td>
                                        <?php
                                            // Buscar el masaje correspondiente a la persona actual ($i)
                                            $masajeAsignado = $visita->masajes->firstWhere('persona', $i);
                                        ?>
                
                                        <?php if($masajeAsignado && $masajeAsignado->user): ?>
                                            <strong style="color:#039B7B;"><?php echo e($masajeAsignado->user->name); ?></strong>
                                        <?php else: ?>
                                        <?php if(Auth::user()->has_role(config('app.admin_role'))): ?>
                                            <strong class="red-text">No asignado</strong>
                                        <?php else: ?>
                                            
                                        <!-- Mostrar el botón si no hay masoterapeuta asignada -->
                                        <form action="<?php echo e(route('backoffice.masaje.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id_visita" value="<?php echo e($visita->id); ?>">
                                            <input type="hidden" name="persona_numero" value="<?php echo e($i); ?>">
                                            <button type="submit" class="btn-floating">
                                                <i class="material-icons">pan_tool</i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endfor; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                                        

                </tbody>
            </table>
        
        



    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<script>
    $(document).ready(function () {
        function actualizarEstado() {
            $('.estado').each(function () {
                let estado = $(this);
                let horaActual = new Date();
                let hora = `${horaActual.getHours().toString().padStart(2, '0')}:${horaActual.getMinutes().toString().padStart(2, '0')}`;

                const horaInicio = estado.attr('data-inicio');
                const horaFin = estado.attr('data-fin');

                // Convertir horas a Date para comparar
                let hoy = new Date().toISOString().split('T')[0]; // Fecha de hoy en formato yyyy-mm-dd
                let fechaHoraActual = new Date(`${hoy}T${hora}`);
                let fechaHoraInicio = new Date(`${hoy}T${horaInicio}`);
                let fechaHoraFin = new Date(`${hoy}T${horaFin}`);

                if (fechaHoraActual < fechaHoraInicio) {
                    estado.text('Pendiente');
                    estado.removeClass('deep-orange green').addClass('cyan');
                } else if (fechaHoraActual >= fechaHoraInicio && fechaHoraActual <= fechaHoraFin) {
                    estado.text('En Proceso');
                    estado.removeClass('cyan green').addClass('deep-orange');
                } else if (fechaHoraActual > fechaHoraFin) {
                    estado.text('Completado');
                    estado.removeClass('cyan deep-orange').addClass('green');
                }
            });
        }

        // Actualiza el estado cada segundo
        setInterval(actualizarEstado, 1000);
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/masaje/index.blade.php ENDPATH**/ ?>