<div class="collection">


    <a href="" class="collection-item active">

        <h5>Consumo:</h5>
    </a>


    <?php if(is_null($reserva->venta->consumos)): ?>
    <a class="collection-item center">Esta cuenta no posee consumos. </a>
    <a href="<?php echo e(route('backoffice.venta.consumo.create_service', $reserva->venta)); ?>"
        class="btn-floating activator btn-move-up waves-effect waves-light accent-2 z-depth-0 right tooltipped"
        data-position="bottom" data-tooltip="Agregar Servicio">
        <i class="material-icons">hot_tub</i>
    </a>
    <a href="<?php echo e(route('backoffice.venta.consumo.create', $reserva->venta)); ?>"
        class="btn-floating activator btn-move-up waves-effect waves-light accent-2 z-depth-0 right mr-5 tooltipped"
        data-position="bottom" data-tooltip="Agregar Producto">
        <i class="material-icons">local_bar</i>
    </a>
    <?php else: ?>
    <?php $__currentLoopData = $reserva->venta->consumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $consumo->detallesConsumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <a class="collection-item center-align valign-wrapper">
        <?php echo e($detalle->producto->nombre); ?> - Cantidad: <?php echo e($detalle->cantidad_producto); ?>

    </a>

      
        
        


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('backoffice.venta.consumo.create_service', $reserva->venta)); ?>"
        class="btn-floating activator btn-move-up waves-effect waves-light accent-2 z-depth-0 right tooltipped"
        data-position="bottom" data-tooltip="Agregar Servicio">
        <i class="material-icons">hot_tub</i>
    </a>
    <a href="<?php echo e(route('backoffice.venta.consumo.create', $reserva->venta)); ?>"
        class="btn-floating activator btn-move-up waves-effect waves-light accent-2 z-depth-0 right mr-5 tooltipped"
        data-position="bottom" data-tooltip="Agregar Producto">
        <i class="material-icons">local_bar</i>
    </a>
    <?php endif; ?>

</div><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/reserva/includes/consumo.blade.php ENDPATH**/ ?>