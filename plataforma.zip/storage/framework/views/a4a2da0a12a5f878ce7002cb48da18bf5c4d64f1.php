<?php $__env->startSection('title', $role->name); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.role.index')); ?>">Roles del Sistema</a></li>
<li><?php echo e($role->name); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
    <p class="caption"><strong>Rol:</strong> <?php echo e($role->name); ?></p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="row">
            <div class="col s12 m8 offset-m2">
                <div class="card">
                  <div class="card-content">
                    <span class="card-title">Usuario con el rol de <?php echo e($role->name); ?></span>
                      <p><strong>Descripción: </strong><?php echo e($role->description); ?></p>
                      <p><strong>Slug: </strong><?php echo e($role->slug); ?></p>
                  </div>
                  <div class="card-action">
                      <a href="<?php echo e(route('backoffice.role.edit', $role)); ?>">Editar</a>
                      <a href="#" style="color: red" onclick="enviar_formulario()">Eliminar</a>
                  </div>
                </div>
            </div>
        </div>

        <div class="row">
  <div class="col s12 m8 offset-m2">
      <div class="card">
        <div class="card-content">
          <span class="card-title">Permisos del rol</span>
          <table>
            <thead>
          <tr>
              <th>Nombre</th>
              <th>Slug</th>
              <th>Descripción</th>
              <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
         <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><a href="<?php echo e(route ('backoffice.permission.show', $permission)); ?>"><?php echo e($permission->name); ?></a></td>
            <td><?php echo e($permission->slug); ?></td>
            <td><?php echo e($permission->description); ?></td>
            <td><a href="<?php echo e(route ('backoffice.permission.edit', $permission)); ?>">Editar</a></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
                  </div>
                </div>
            </div>
        </div>
    </div>
</div>
<form method="post" action="<?php echo e(route('backoffice.role.destroy', $role)); ?> " name="delete_form">
<?php echo e(csrf_field()); ?>

<?php echo e(method_field('DELETE')); ?>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<script>
 function enviar_formulario()
 {
     Swal.fire({
         title: "¿Deseas eliminar este rol?",
         text: "Esta acción no se puede deshacer",
         type: "warning",
         showCancelButton: true,
         confirmButtonText: "Si, continuar",
         cancelButtonText: "No, cancelar",
         closeOnCancel: false,
         closeOnConfirm: true
     }).then((result)=> {
         if(result.value){
             document.delete_form.submit();
         }else{
             Swal.fire(
                 'Operación Cancelada',
                 'Registro no eliminado',
                 'error'
             )
         }
     });
 }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/role/show.blade.php ENDPATH**/ ?>