<?php $__env->startSection('title', 'Permisos del Sistema'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<li><a href="<?php echo e(route('backoffice.permission.index')); ?>">Permisos del Sistema</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dropdown_settings'); ?>
<li><a href="<?php echo e(route('backoffice.permission.create')); ?>" class="grey-text text-darken-2">Crear Permiso</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
    <p class="caption"><strong>Permisos del Sistema</strong></p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="row">
            <div class="col s12">
                <div class="card-panel">
                    <div class="row">





                        <div class="card">
                            <div class="card-content gradient-45deg-light-blue-cyan">
                                <h5 class="white-text" id="nombreSeleccion">nombre permiso</h5>
                            </div>

                            <div class="card-tabs">
                                <ul class="tabs tabs-fixed-width">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="tab"><a href="#role_<?php echo e($role->id); ?>" id="seleccion"><?php echo e($role->name); ?></a>
                                    </li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>

                            <div class="card-content grey lighten-4">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="role_<?php echo e($role->id); ?>" class="tipo-section">

                                    <table class="striped">
                                        <thead>
                                            <tr>
                                                <th>Nombre del Permiso</th>
                                                <th>Descripción</th>
                                                <th>Slug</th>
                                                <th>Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($role->permissions->isEmpty()): ?>

                                            <tr>
                                                <td>El rol <strong><?php echo e($role->name); ?></strong> No registra permisos</td>
                                            </tr>


                                            <?php else: ?>

                                            <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><a
                                                        href="<?php echo e(route ('backoffice.permission.show', $permission)); ?>"><?php echo e($permission->name); ?></a>
                                                </td>
                                                <td><?php echo e($permission->description); ?></td>
                                                <td><?php echo e($permission->slug); ?></td>
                                                <td><a
                                                        href="<?php echo e(route('backoffice.permission.edit', $permission)); ?>">Editar</a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>









                        

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<script>
    $(document).ready(function () {
        // let nombreTipo = $('#nombreSeleccion').text();
        let seleccion = $('#seleccion').text();
        
        
            // Obtener el texto del primer tab visible y mostrarlo en el h5 al cargar la página
            let nombreInicial = $('.tabs .tab a.active').text();
            if (!nombreInicial) {
                nombreInicial = $('.tabs .tab a:first').text();
            }
            $('#nombreSeleccion').text('Permisos para el rol: '+nombreInicial); // Mostrar el nombre inicial

            // Escuchar el evento click en las pestañas
            $('.tabs .tab a').on('click', function (e) {
                e.preventDefault();

                // Obtener el texto del enlace seleccionado
                let nombreTipo = $(this).text();

                // Actualizar el contenido del h5 con id "nombreSeleccion"
                $('#nombreSeleccion').text('Permisos para el rol: '+nombreTipo);
            });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.backoffice.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\botacurapp\resources\views/themes/backoffice/pages/permission/index.blade.php ENDPATH**/ ?>