<div id="modalReserva" class="modal">
    <div class="modal-content">
      <h4>Detalles de la Reserva</h4>
      <p><strong>Cliente:</strong> <span id="modalClienteNombre"></span></p>
      <p><strong>Fecha de la Reserva:</strong> <span id="modalFechaReserva"></span></p>
      <p><strong>Cantidad de personas:</strong> <span id="modalPersonasReserva"> </span> Asistentes</p>
      <p><strong>Cantidad de masajes:</strong> <span id="modalMasajeReserva"> </span> Masajes</p>
      <p><strong>Observacion:</strong> <span id="modalObservacionReserva"></span></p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Cerrar</a>
    </div>
  </div>