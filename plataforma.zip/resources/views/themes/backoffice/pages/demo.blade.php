@extends('themes.backoffice.layouts.admin')

@section('title','Página Demo')

@section('head')
@endsection

@section('breadcrumbs')
@endsection


@section('dropdown_settings')
@endsection

@section('content')
<div class="section">
    <p class="caption"><strong>Reservaciones</strong></p>
    <div class="divider"></div>
    <div id="basic-form" class="section">
        <div class="row">
            <div class="col s12 ">
    

                    


            </div>
        </div>
    </div>
</div>
@endsection


@section('foot')
@endsection
