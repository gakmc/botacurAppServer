<footer class="page-footer gradient-45deg-light-blue-cyan">
    <div class="footer-copyright">
        <div class="container">
            <span>
                Copyright ©
                <script type="text/javascript">
                    document.write(new Date().getFullYear());
                </script>
            </span>
        </div>
    </div>
</footer>